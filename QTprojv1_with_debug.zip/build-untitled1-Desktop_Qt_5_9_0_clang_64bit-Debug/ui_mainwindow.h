/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QPushButton *botprocess;
    QPushButton *botrandom;
    QPushButton *botclean;
    QTextBrowser *textprocess;
    QTextBrowser *textout;
    QLabel *labelinp;
    QLabel *labelout;
    QTextEdit *textinput;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(698, 593);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        botprocess = new QPushButton(centralWidget);
        botprocess->setObjectName(QStringLiteral("botprocess"));
        botprocess->setGeometry(QRect(240, 270, 93, 28));
        botrandom = new QPushButton(centralWidget);
        botrandom->setObjectName(QStringLiteral("botrandom"));
        botrandom->setGeometry(QRect(40, 270, 93, 28));
        botclean = new QPushButton(centralWidget);
        botclean->setObjectName(QStringLiteral("botclean"));
        botclean->setGeometry(QRect(140, 270, 93, 28));
        textprocess = new QTextBrowser(centralWidget);
        textprocess->setObjectName(QStringLiteral("textprocess"));
        textprocess->setGeometry(QRect(40, 320, 291, 192));
        textout = new QTextBrowser(centralWidget);
        textout->setObjectName(QStringLiteral("textout"));
        textout->setGeometry(QRect(360, 120, 291, 391));
        labelinp = new QLabel(centralWidget);
        labelinp->setObjectName(QStringLiteral("labelinp"));
        labelinp->setGeometry(QRect(40, 20, 72, 15));
        labelout = new QLabel(centralWidget);
        labelout->setObjectName(QStringLiteral("labelout"));
        labelout->setGeometry(QRect(360, 90, 72, 15));
        textinput = new QTextEdit(centralWidget);
        textinput->setObjectName(QStringLiteral("textinput"));
        textinput->setGeometry(QRect(40, 60, 291, 191));
        MainWindow->setCentralWidget(centralWidget);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
        botprocess->setText(QApplication::translate("MainWindow", "Process", Q_NULLPTR));
        botrandom->setText(QApplication::translate("MainWindow", "Rand", Q_NULLPTR));
        botclean->setText(QApplication::translate("MainWindow", "Clean", Q_NULLPTR));
        labelinp->setText(QApplication::translate("MainWindow", "Input", Q_NULLPTR));
        labelout->setText(QApplication::translate("MainWindow", "Output", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
