#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "stdlib.h"
#include "time.h"


int i, j = 0;
int num[1024], len = 0, lenoflen = 0;

char c, chr[1024], tep[3], tep_len[64], mes[1024] = { 0 };

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_botrandom_clicked()//random函数
{
    ui->textinput->clear();
    ui->textout->clear();
    ui->textprocess->clear();
    chr[1024] = {0};
    srand((unsigned int)time(0));
    int a = rand() % 96 + 1;  // 1-96个字符，8-768bits长度
    for (i = 0; i < a; i++)
    {
        int chan = rand() % 3;
        if (chan == 0)
            chr[i] = rand() % 10 + 48;  //0-9
        if (chan == 1)
            chr[i] = rand() % 10 + 65;  //A-Z
        if (chan == 2)
            chr[i] = rand() % 10 + 97;	//a-z
    }
    chr[i] = '\0';
    ui->textinput->append(chr);
}

void MainWindow::on_botclean_clicked()//clean
{
    ui->textinput->clear();
    ui->textout->clear();
    ui->textprocess->clear();
}

void MainWindow::on_botprocess_clicked()
{
    //QString strTxtEdt = ui->textinput->toPlainText();
    //for(i=0;strTxtEdt != '\0';i++)
    //{
    //    chr[j] = strTxtEdt[j];
    //}
    while (chr[j] != '\0')    //ASCII码转换
    {
       // num[j] = ((chr[j] - 'a') + 97);
        num[j] = chr[j];
        sprintf(tep, "%x", num[j]);//把num转成16进制写入tep转字符串
        strcat(mes, tep);//拼接tep和message，此时已经都是字符串的拼接
        j++;
    }
    mes[2 * j] = '\0';//加结尾
    ui->textprocess->append(mes);

    len = strlen(mes) * 4;	//bits
    //printf("\n\nMessage Length >>> %d (%x)bits\n\n", len, len);//输出message长度
    sprintf(tep_len, "%x", len); //len写入teplen转为字符串，和上面的sprintf操作一样
    lenoflen = strlen(tep_len);//用来确认最后需要空出来增加位数的长度
    char eg[4];
    strcpy(eg, "8");
    strcat(mes, eg);
    strcpy(eg, "0");
    if (len > 448)
        while (len < 1024 - 4 * lenoflen)
        {// >448时用1024（2组）懒得处理了
            strcat(mes, eg);
            len = strlen(mes) * 4;
        }
    if (len < 448)
        while (len < 512 - 4 * lenoflen)
        {//<448 应用512就一组
            strcat(mes, eg);
            len = strlen(mes) * 4;
        }
    strcat(mes, tep_len);//拼接最后的长度位置
    ui->textout->append(mes);
}
