#include "mainwindow.h"
#include "stdio.h"
#include "string.h"
#include "stdlib.h"
#include "time.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();

    return a.exec();
}
